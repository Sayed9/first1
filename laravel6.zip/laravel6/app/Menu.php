<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Menu extends Model {

    use SoftDeletes;

    protected $table = 'menu';
    protected $primaryKey = 'menu_id';
    protected $dates = ['deleted_at'];
    protected $fillable = [
        'name', 'image','quantity','price'
    ];


}
