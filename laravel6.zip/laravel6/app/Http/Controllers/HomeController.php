<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Session;
use File;
use Illuminate\Support\Facades\DB;
use Redirect;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\View;

class HomeController extends Controller {
    public function contact_us() {
        return view('contact_us');
    }
}
