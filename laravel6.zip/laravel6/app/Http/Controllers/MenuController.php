<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Menu;
use Session;
use File;
use Illuminate\Support\Facades\DB;
use Redirect;
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\View;

class MenuController extends Controller {


    public function menu() {
        $menus = new Menu();
        $menus = $menus
            ->orderBy('menu_id', 'desc')
            ->whereNull('deleted_at')
            ->get();
        return view('menu', compact('menus'));
    }

 
}
