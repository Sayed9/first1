<!DOCTYPE html>
<html lang="en">
<head>
    <title>Laravel Project</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href=" <?php echo e(url('menu')); ?>">Menu</a></li>
            <li><a href="<?php echo e(url('contact-us')); ?>">Contact Us</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 style="text-align: center">View Menu</h3>
        </div>
        <div class="panel-body">

            <table id="myTable" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>#</th>

                    <th><a data-sort="sub_master_name">Name</a></th>
                    <th><a data-sort="sub_master_name">Image</a></th>
                    <th><a data-sort="sub_master_name">Price</a></th>
                    <th><a data-sort="sub_master_name">Quantity</a></th>
                    <th><a>Action</a></th>
                </tr>

                </thead>
                <tbody>

                <?php if(isset($menus)): ?>
                    <?php
                        $i = 1
                    ?>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="gradeX">
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($menu->name); ?></td>
                            <td>
                             
                                <?php
                                if($menu->image == '')
                                {
                                ?>
                                <img style="height: 80px;" class="socialite-logo" src="<?php echo e(URL::asset('product.jpeg')); ?>">

                                <?php
                                }else{
                                ?>
                                <img style="height: 80px;width:100px;" src="<?php echo e(URL::asset($menu->image)); ?>">
                                <?php
                                }
                                ?>
                            </td>
                            <td><?php echo e($menu->price); ?></td>
                            <td><?php echo e($menu->quantity); ?></td>
                            <td>
                                <a href="" id="" class="btn btn-primary">
                                        Add to Cart</a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>

        </div>

    </div>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\food_delivery\laravel6\resources\views/menu.blade.php ENDPATH**/ ?>