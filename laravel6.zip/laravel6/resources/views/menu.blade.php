<!DOCTYPE html>
<html lang="en">
<head>
    <title>Laravel Project</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li class="active"><a href="{{ url('/')}}">Home</a></li>
            <li><a href=" {{ url('menu')}}">Menu</a></li>
            <li><a href="{{ url('contact-us')}}">Contact Us</a></li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 style="text-align: center">View Menu</h3>
        </div>
        <div class="panel-body">

            <table id="myTable" class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>#</th>

                    <th><a data-sort="sub_master_name">Name</a></th>
                    <th><a data-sort="sub_master_name">Image</a></th>
                    <th><a data-sort="sub_master_name">Price</a></th>
                    <th><a data-sort="sub_master_name">Quantity</a></th>
                    <th><a>Action</a></th>
                </tr>

                </thead>
                <tbody>

                @if(isset($menus))
                    @php
                        $i = 1
                    @endphp
                    @foreach($menus as $menu)

                        <tr class="gradeX">
                            <td>{{$i++}}</td>
                            <td>{{$menu->name}}</td>
                            <td>
                             
                                <?php
                                if($menu->image == '')
                                {
                                ?>
                                <img style="height: 80px;" class="socialite-logo" src="{{ URL::asset('product.jpeg') }}">

                                <?php
                                }else{
                                ?>
                                <img style="height: 80px;width:100px;" src="{{ URL::asset($menu->image) }}">
                                <?php
                                }
                                ?>
                            </td>
                            <td>{{$menu->price}}</td>
                            <td>{{$menu->quantity}}</td>
                            <td>
                                <a href="" id="" class="btn btn-primary">
                                        Add to Cart</a>

                            </td>
                        </tr>
                    @endforeach
                @endif
                </tbody>
            </table>

        </div>

    </div>

</div>

</body>
</html>
