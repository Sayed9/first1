<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*Menu Start*/
Route::get('menu', [
    'as' => 'menu',
    'uses' => 'MenuController@menu'
]);
/*Menu End*/

// Contact-us start
Route::get('contact-us', [
    'as' => 'contact-us',
    'uses' => 'HomeController@contact_us'
]);
//Contact-us start

