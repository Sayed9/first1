<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Menu;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Image;
use Illuminate\Support\Str;

class MenuController extends Controller
{
    public function index()
    {

        return view('admin.menu.index', [

            'menus' => Menu::get()
        ]);
    }

    public function create()
    {
        return view('admin.menu.create');
    }



    public function store(Request $request)
    {
        // echo '<pre>';
        // // echo $request->category_url;
        // print_r($request->all());
        // die();

        // Menu Validation
        $rules = [
            'name' => 'required',
            'image' => 'unique:menus,image',

        ];

        $customMessages = [
            'menu_title.required' => 'The Menu Name field is required.',
            'image.unique' => 'Please change the image name.'
        ];

        $this->validate($request, $rules, $customMessages);



        $menu_id = Menu::insertGetId([
            'name' => $request->menu_title,
            'quantity' => $request->quantity,
            'price' => $request->price,

        ]);


        if ($request->hasFile('image')) {
            $image_tmp = $request->file('image');
            if ($image_tmp->isValid()) {
                // Get image extension
                // $originalname =Str::slug() $image_tmp->getClientOriginalName();
                $originalname =Str::slug($image_tmp->getClientOriginalName());
                $extension = $image_tmp->getClientOriginalExtension();
                // genarate image name
                $imageName = $originalname . '-' . $menu_id . '-' . rand(111, 99999) . '.' . $extension;
                $large_image_path = 'images/menu_images/' . $imageName;

                //Upload the image
                Image::make($image_tmp)->save($large_image_path);
                Menu::find($menu_id)->update([
                    'image' => $imageName
                ]);
            }
        }


        return back()->with('success_message', $request->menu_title . ' menu added sucessfully');
    }


    public function EditMenu($Menu_id)
    {

        $Menu_info = Menu::find($Menu_id);

        return view('admin.Menu.edit', [
            'Menu_info' => $Menu_info,
        ]);
    }
}
